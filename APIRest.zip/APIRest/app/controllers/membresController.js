// utilisation du Model Sportif pour faire le lien avec la BD
var membreModel = require('../models/membreModel');
// définition du controller sous la forme d'un objet JS avec des propriétés
var membresController = {
    getMembre : function(req,res){
        // find
        membreModel.find({},{_id : 0, nom : 1, prenom : 1}).sort({nom : 1})
        .then((Membre)=>res.send(Membre))
        .catch((err) => res.send(err.message));
    },

    index : function(req,res){
        membreModel.find({id: req.params.id},{_id : 0, nom : 1, prenom : 1}).sort({nom : 1})
        .then((Membre)=>res.send(Membre))
        .catch((err) => res.send(err.message));
    },

    ajout : function(req,res){

        if(membreModel == null){
            res.json({"status" : false, "message": "ce membre existe déjà"})
        }else {

            var newMembre = new membreModel(req.body);
            
            newMembre.validate()
            .then( () => {return newMembre.save()});
        }
        
    }
    .then(()=>res.json({"status":true,"membre": "membre ajouté" }))
    .catch((err) => res.json({"status":true,"message": "membre validation failed : "+err.message })),

    modification : function(req,res){

    },

    suppression : function(req,res){

    },
} // interface du module
module.exports = membresController;
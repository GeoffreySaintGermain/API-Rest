// utilisation d'un routeur Express
var express = require('express');
var routerMembres = express.Router();
// utilisation du controlleur de gestion des sportifs
var membresController = require('../controllers/membresController');


// route pour la liste des sportifs
// utilisant la méthode liste du controlleur
routerMembres.get('/', membresController.getMembre);
routerMembres.get('/:id', membresController.index);
routerMembres.post('/', membresController.ajout);
//routerMembres.put('/', membresController.modification);
//routerMembres.delete('/', membresController.suppression);
// interface du module
module.exports = routerMembres;
